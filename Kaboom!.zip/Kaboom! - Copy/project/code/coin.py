import pygame
from pygame.math import Vector2 as vector
from os import walk
from collections import deque

coinStack = []
damageStack = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]

class Coin(pygame.sprite.Sprite):
	def __init__(self, pos, groups, path, player):
		super().__init__(groups)

		self.import_assets(path)
		self.frame_index = 0
		self.status = 'down_idle'

		self.image = self.animations[self.status][self.frame_index]
		self.rect = self.image.get_rect(center = pos)

		# float-based movement
		self.pos = vector(self.rect.center)
		self.direction = vector()

		self.coinStack = coinStack
		self.damageStack = damageStack

	def import_assets(self,path):
	    self.animations = {}

	    for index, folder in enumerate(walk(path)):
	        if index == 0:
	            for name in folder[1]:
	                self.animations[name] = []
	        else:
	        	# i chose sorted() since there are so many coins and it is also more efficient than most other sorting algorithms
	            for file_name in sorted(folder[2], key=lambda string: int(string.split('.')[0])):
	                path = folder[0].replace('\\', '/') + '/' + file_name
	                surf = pygame.image.load(path).convert_alpha()
	                key = folder[0].split('\\')[1]
	                self.animations[key].append(surf)

	def animate(self,dt):
		current_animation = self.animations[self.status]

		self.frame_index += 7 * dt

		if self.frame_index >= len(current_animation):
			self.frame_index = 0

		self.image = current_animation[int(self.frame_index)]
		self.mask = pygame.mask.from_surface(self.image)

	def get_player_distance_direction(self):
		enemy_pos = vector(self.rect.center)
		player_pos = vector(self.player.rect.center)
		distance = (player_pos - enemy_pos).magnitude()

		direction = (player_pos - enemy_pos).normalize()

		return (distance, direction)

	def pushStack(self):
		coinStack.append(self)
		print(f"Current Coin Inventory: {len(coinStack)}")
		return len(coinStack)

	def dequeue(self):
		if len(coinStack) > 0:
			coinStack.pop(0)
			print(f"Current Coin Inventory: {len(coinStack)}")
			return len(coinStack)
		else:
			print(f"Current Coin Inventory: {len(coinStack)}")
			return 0

	def checkStack(self):
		return len(coinStack)

	def reflectDamage(self):
		if 0 < len(damageStack) <= 20:
			damageStack.pop(0)
			return len(damageStack)
		else:
			return 0

	def checkDamage(self):
		return len(damageStack)

	def check_death(self):
		distance = self.get_player_distance_direction()[0]
		if -16 <= distance <= 16:
			self.music = pygame.mixer.Sound('../sound/collected.wav')
			self.music.play()
			self.kill()
			self.pushStack()

	def update(self,dt):
		self.animate(dt)
		self.check_death()