import pygame, sys
from pygame.math import Vector2 as vector
from settings import *
from pytmx.util_pygame import load_pygame
from coin import Coin, coinStack, damageStack

class GUI:
	def __init__(self):
		self.display_surface = pygame.display.get_surface()
		self.font = pygame.font.Font(UI_FONT, UI_FONTSIZE)

		self.coin_bar_rect = pygame.Rect(10,10,BAR_WIDTH,BAR_HEIGHT)
		self.damage_bar_rect = pygame.Rect(10,34,BAR_WIDTH,BAR_HEIGHT)

	def show_coin_bar(self,current,max_amount,bg_rect,color):
		pygame.draw.rect(self.display_surface,UI_BG_COLOR,bg_rect)

		currentStack = Coin.checkStack(coinStack)
		percentStack = currentStack / 80
		current_width = bg_rect.width * percentStack
		current_rect = bg_rect.copy()
		current_rect.width = current_width

		pygame.draw.rect(self.display_surface,color,current_rect)
		pygame.draw.rect(self.display_surface,UI_BORDER_COLOR,bg_rect,3)

	def show_damage_bar(self,current,max_amount,bg_rect,color):
		pygame.draw.rect(self.display_surface,UI_BG_COLOR,bg_rect)

		currentStack = Coin.checkDamage(damageStack)
		percentStack = currentStack / 20
		current_width = bg_rect.width * percentStack
		current_rect = bg_rect.copy()
		current_rect.width = current_width

		pygame.draw.rect(self.display_surface,color,current_rect)
		pygame.draw.rect(self.display_surface,UI_BORDER_COLOR,bg_rect,3)

	def display(self):
		self.show_coin_bar(Coin.checkStack(coinStack), 80, self.coin_bar_rect, COIN_COLOR)
		self.show_damage_bar(Coin.checkDamage(damageStack), 20, self.damage_bar_rect, DANGER_COLOR)