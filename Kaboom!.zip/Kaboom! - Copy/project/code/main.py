import pygame, sys
from pygame.math import Vector2 as vector
from settings import *
from player import Player
from pytmx.util_pygame import load_pygame
from sprite import Sprite
from monster import Schoolgirl
from coin import Coin, damageStack, coinStack
from gui import GUI

def minecraftText(font_size):
	return pygame.font.Font(UI_FONT, UI_FONTSIZE)

def animateText(text, font, surface, x, y, color): #yung text sa title screen na natakbo
	#moving text
	clock = pygame.time.Clock()
	if len(text) > 49:
		textLine1 = text[:49]
		textLine2 = text[48:]
	else:
		textLine1 = text
		textLine2 = ""
	i = 0
	for letter in textLine1:
		displayLine1 = textLine1[:i]
		textobj1 = font.render(displayLine1,1,color)
		textrect1 = textobj1.get_rect()
		textrect1.topleft = (x,y)
		surface.blit(textobj1,textrect1)
		pygame.display.update()
		clock.tick(15)
		i += 1
	j = 0
	for letter in textLine2:
		displayLine2 = textLine2[:j]
		textobj2 = font.render(textLine2,1,color)
		textrect2 = textobj2.get_rect()
		textrect2.topleft = (x,y+10)
		surface.blit(textobj2,textrect2)
		pygame.display.update()
		j += 1

class AllSprites(pygame.sprite.Group):
	def __init__(self):
		super().__init__()
		self.offset = vector()
		self.display_surface = pygame.display.get_surface()
		self.bg = pygame.image.load('../graphics/tilesets/map2.png').convert()

	def customize_draw(self,player):

		# change offset vector
		self.offset.x = player.rect.centerx - WINDOW_WIDTH / 2
		self.offset.y = player.rect.centery - WINDOW_HEIGHT / 2

		# blit the surface

		# bg
		self.display_surface.blit(self.bg,-self.offset)

		# sprites inside of the group (player)
		for sprite in sorted(self.sprites(), key = lambda sprite: sprite.rect.centery):
			offset_rect = sprite.image.get_rect(center = sprite.rect.center)
			offset_rect.center -= self.offset
			self.display_surface.blit(sprite.image,offset_rect)

class LandingPage:
	def __init__(self):
		pygame.init()
		self.display_surface = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
		pygame.display.set_caption('Kaboom!')
		self.clock = pygame.time.Clock()
		self.font = pygame.font.Font(None, 36)

	def run(self):
		font = pygame.font.SysFont(None, 20)
		TEXTSURF = pygame.display.set_mode((WINDOW_WIDTH,WINDOW_HEIGHT))
		landingBackground = pygame.image.load("../graphics/other/bg_trial1.jpg")
		while True:
			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					pygame.quit()
					sys.exit()
				elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
					return  # Start the game when left-click is pressed

			self.display_surface.blit(landingBackground, (0,0))
			animateText("Click anywhere to begin...", font, TEXTSURF, 200, 500, (51,51,51))

			pygame.display.update()
			self.clock.tick(60)

class WinPage:
	def __init__(self):
		pygame.init()
		self.display_surface = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
		pygame.display.set_caption('Kaboom!')
		self.clock = pygame.time.Clock()
		self.font = pygame.font.Font(None, 72)

		self.playButton = Button(pygame.image.load("../graphics/other/play_button.png"),(640,200),"WIN",minecraftText(75),BASE_COLOR)

	def run(self):
		font = pygame.font.SysFont(None, 20)
		TEXTSURF = pygame.display.set_mode((WINDOW_WIDTH,WINDOW_HEIGHT))
		landingBackground = pygame.image.load("../graphics/other/bg_trial1.jpg")
		while True:
			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					pygame.quit()
					sys.exit()
				elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
					pygame.quit()
					sys.exit()  # Start the game when left-click is pressed

			self.display_surface.blit(landingBackground, (0,0))

			self.playButton.update(self.display_surface)

			animateText("Click anywhere to exit...", font, TEXTSURF, 200, 500, (51,51,51))

			pygame.display.update()

class LosePage:
	def __init__(self):
		pygame.init()
		self.display_surface = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
		pygame.display.set_caption('Kaboom!')
		self.clock = pygame.time.Clock()
		self.font = pygame.font.Font(None, 72)

		self.playButton = Button(pygame.image.load("../graphics/other/play_button.png"),(640,200),"LOSE",minecraftText(75),BASE_COLOR)

	def run(self):
		font = pygame.font.SysFont(None, 20)
		TEXTSURF = pygame.display.set_mode((WINDOW_WIDTH,WINDOW_HEIGHT))
		landingBackground = pygame.image.load("../graphics/other/bg_trial1.jpg")
		while True:
			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					pygame.quit()
					sys.exit()
				elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
					pygame.quit()
					sys.exit()  # Start the game when left-click is pressed

			self.display_surface.blit(landingBackground, (0,0))

			self.playButton.update(self.display_surface)

			animateText("Click anywhere to exit...", font, TEXTSURF, 200, 500, (51,51,51))

			pygame.display.update()

class Button:
	def __init__(self,display,pos,inputAction,font,baseColor):
		self.display = display
		self.x_point = pos[0]
		self.y_point = pos[1]
		self.font = font
		self.baseColor = baseColor
		self.inputAction = inputAction
		self.text = self.font.render(self.inputAction, True, self.baseColor)
		if self.display is None:
			self.display = self.text
		self.rect = self.display.get_rect(center=(self.x_point, self.y_point))
		self.text_rect = self.text.get_rect(center=(self.x_point, self.y_point))

	def update(self,displayScreen):
		if self.display is not None:
			displayScreen.blit(self.display,self.rect)
		displayScreen.blit(self.text,self.text_rect)

class Game:
	def __init__(self):
		pygame.init()
		self.display_surface = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
		pygame.display.set_caption('Kaboom!')
		self.clock = pygame.time.Clock()

		# groups
		self.all_sprites = AllSprites()
		self.obstacles = pygame.sprite.Group()

		self.gui = GUI()

		self.current_music = None
		if self.current_music is not None:
			self.current_music.play(loops=-1)
		self.music = None

		self.setup()

	def setup(self):
		tmx_map = load_pygame('../data/finalmap.tmx')

		# tiles
		for x, y, surf in tmx_map.get_layer_by_name('Fence').tiles():
			Sprite((x * 32, y * 32), surf, [self.all_sprites, self.obstacles])

		# objects
		for obj in tmx_map.get_layer_by_name('Entities'):
			if obj.name == 'Player':
				self.player = Player(
					pos=(obj.x, obj.y),
					groups=self.all_sprites,
					path=PATHS['player'],
					collision_sprites=self.obstacles)

			if obj.name == 'Schoolgirl':
				Schoolgirl((obj.x, obj.y), self.all_sprites, PATHS['schoolgirl'], self.obstacles, self.player)

		for obj in tmx_map.get_layer_by_name('Coins'):
			if obj.name == 'Coin':
				coin = Coin((obj.x, obj.y), self.all_sprites, PATHS['coin'], self.player)
				coin.player = self.player

	def update_music(self):
		player_center = self.player.rect.center

		regions = [ # 2D ARRAY
			{'music': 'littleroot_town.mp3', 'rect': [0, 0, 2176, 5088]},
			{'music': 'slateport_city.mp3', 'rect': [2176, 0, 7648, 3000]},
			{'music': 'dewford_town.mp3', 'rect': [0, 5088, 7648, 7648]},
			{'music': 'kotoki_town.mp3', 'rect': [2176, 3000, 7648, 5088]}
		]

		# Check position --> update bg music
		for region in regions:
			x_min, y_min, x_max, y_max = region['rect']
			if x_min <= player_center[0] <= x_max and y_min <= player_center[1] <= y_max:
				new_music = region['music']
				break

		# pag nagchange new_music, play corresponding sound
		if new_music != self.current_music:
			if self.music is not None:
				self.music.stop()
			
			self.music = pygame.mixer.Sound(f'../sound/{new_music}')
			self.music.play(loops=-1)
			self.current_music = new_music

	def run(self):
		landing_page = LandingPage()
		win_page = WinPage()
		lose_page = LosePage()
		landing_page.run()

		while True:
			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					pygame.quit()
					sys.exit()
			dt = self.clock.tick() / 1000

            # update groups
			self.all_sprites.update(dt)

			self.update_music()

			# draw groups
			self.display_surface.fill('black')
			self.all_sprites.customize_draw(self.player)

			self.gui.display()

			pygame.display.update()

			if self.player.exit() == 0:
				lose_page.run()
			elif Coin.checkStack(coinStack) >= 80:
				win_page.run()

if __name__ == '__main__':
	game = Game()
	game.run()