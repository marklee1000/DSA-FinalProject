WINDOW_WIDTH, WINDOW_HEIGHT = 1280,720

# gui
BAR_HEIGHT = 20
BAR_WIDTH = 200
UI_FONT = '../graphics/font/joystix.ttf'
UI_FONTSIZE = 18

UI_BG_COLOR = '#222222'
UI_BORDER_COLOR = '#111111'
TEXT_COLOR = '#EEEEEE'

COIN_COLOR = 'gold'
DANGER_COLOR = 'red'

BASE_COLOR = 'black'

PATHS = {
	'player': '../graphics/player1',
	'schoolgirl': '../graphics/npc/Boss-4',
	'coin': '../graphics/objects/coin'
}