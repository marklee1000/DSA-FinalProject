import pygame
from pygame.math import Vector2 as vector
from os import walk

class Entity(pygame.sprite.Sprite):
	def __init__(self, pos, groups, path, collision_sprites):
		super().__init__(groups)

		self.import_assets(path)
		self.frame_index = 0
		self.status = 'down_idle'

		self.image = self.animations[self.status][self.frame_index]
		self.rect = self.image.get_rect(center = pos)

		# float-based movement
		self.pos = vector(self.rect.center)
		self.direction = vector()
		self.speed = 200

		# attack
		self.attacking = False

		# collisions
		self.hitbox = self.rect.inflate(-self.rect.width * 0.5, -self.rect.height / 2)
		self.collision_sprites = collision_sprites

	def insertion_sort(self, file_name):
		for i in range(1, len(file_name)):
			key = file_name[i]
			j = i - 1
			while j >= 0 and int(key.split('.')[0]) < int(file_name[j].split('.')[0]):
				file_name[j+1] = file_name[j]
				j -= 1
			file_name[j+1] = key

	def import_assets(self,path):
		self.animations = {} # empty set for the animation frames

		# loop ng animations
		for index,folder in enumerate(walk(path)):
			if index == 0:
				for name in folder[1]:
					self.animations[name] = []
			else:
				file_names = folder[2]
				self.insertion_sort(file_names)

				for file_name in file_names:
					path = folder[0].replace('\\','/') + '/' + file_name
					surf = pygame.image.load(path).convert_alpha()
					key = folder[0].split('\\')[1]
					self.animations[key].append(surf)

	def move(self,dt):
		# normalize
		if self.direction.magnitude() != 0:
			self.direction = self.direction.normalize()

		# horizontal movement
		self.pos.x += self.direction.x * self.speed * dt
		self.hitbox.centerx = round(self.pos.x)
		self.rect.centerx = self.hitbox.centerx
		self.collision('horizontal')

		# vertical movement
		self.pos.y += self.direction.y * self.speed * dt
		self.hitbox.centery = round(self.pos.y)
		self.rect.centery = self.hitbox.centery
		self.collision('vertical')

	def collision(self,direction):
		for sprite in self.collision_sprites.sprites():
			if sprite.hitbox.colliderect(self.hitbox):
				if direction == 'horizontal':
					if self.direction.x > 0: # moving right
						self.hitbox.right = sprite.hitbox.left
					if self.direction.x < 0: # moving left
						self.hitbox.left = sprite.hitbox.right
					self.rect.centerx = self.hitbox.centerx
					self.pos.x = self.hitbox.centerx

				else: # vertical
					if self.direction.y > 0: # moving down
						self.hitbox.bottom = sprite.hitbox.top
					if self.direction.y < 0: # moving up
						self.hitbox.top = sprite.hitbox.bottom
					self.rect.centery = self.hitbox.centery
					self.pos.y = self.hitbox.centery