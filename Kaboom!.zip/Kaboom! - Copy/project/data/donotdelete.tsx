<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="donotdelete" tilewidth="32" tileheight="32" tilecount="40800" columns="204">
 <image source="../graphics/tilesets/spz3zUx.png" width="6528" height="6400"/>
</tileset>
