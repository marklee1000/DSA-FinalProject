<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="map2" tilewidth="32" tileheight="32" tilecount="57600" columns="240">
 <image source="../graphics/tilesets/map2.png" width="7680" height="7680"/>
</tileset>
