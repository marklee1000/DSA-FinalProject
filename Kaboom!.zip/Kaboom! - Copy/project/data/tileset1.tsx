<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="mapa1" tilewidth="32" tileheight="32" tilecount="14400" columns="120">
 <image source="../graphics/tilesets/mapa1.png" width="3840" height="3840"/>
</tileset>
